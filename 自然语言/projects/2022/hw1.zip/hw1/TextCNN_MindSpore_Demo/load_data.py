from tqdm import tqdm
import pickle as pkl
import os


class Preload_Data:

    def __init__(self, config):
        self.UNK, self.PAD = '<UNK>', '<PAD>'
        self.MAX_VOCAB_SIZE = 10000
        self.config = config

    def build_vocab(self, file_path, tokenizer, max_size, min_freq):

        vocab_dic = {}
        with open(file_path, 'r', encoding='UTF-8') as f:
            for line in tqdm(f):
                lin = line.strip()
                if not lin:
                    continue
                content = lin.split('\t')[0]
                for word in tokenizer(content):
                    vocab_dic[word] = vocab_dic.get(word, 0) + 1
            vocab_list = sorted(
                [_ for _ in vocab_dic.items() if _[1] >= min_freq],
                key=lambda x: x[1],
                reverse=True)[:max_size]
            vocab_dic = {
                word_count[0]: idx
                for idx, word_count in enumerate(vocab_list)
            }
            vocab_dic.update({
                self.UNK: len(vocab_dic),
                self.PAD: len(vocab_dic) + 1
            })
        return vocab_dic  # return idx2Word

    def build_dataset(self):
        tokenizer = lambda x: [y for y in x]
        if os.path.exists(self.config.vocab_path):
            vocab = pkl.load(open(self.config.vocab_path, 'rb'))
        else:
            vocab = self.build_vocab(self.config.train_path,
                                     tokenizer=tokenizer,
                                     max_size=self.MAX_VOCAB_SIZE,
                                     min_freq=1)
            pkl.dump(vocab, open(self.config.vocab_path, 'wb'))
        vocab_size = len(vocab)

        def load_dataset(path, pad_size=self.config.pad_size, mode='notest'):
            if mode == 'notest':
                sentences = []
                labels = []
                # seq_lens = []
                # j = 0
                with open(path, 'r', encoding='UTF-8') as f:
                    for line in tqdm(f):
                        # if j < 180000 % 32: # 要保证训练集长度被batch整除，抱歉这里写死了
                        #     j += 1
                        #     continue

                        lin = line.strip()
                        if not lin:
                            continue
                        content, label = lin.split('\t')
                        words_line = []
                        token = tokenizer(content)
                        # seq_len = len(token)
                        if pad_size:
                            if len(token) < pad_size:
                                token.extend([self.PAD] *
                                             (pad_size - len(token)))
                            else:
                                token = token[:pad_size]
                                seq_len = pad_size
                        for word in token:
                            words_line.append(
                                vocab.get(word, vocab.get(self.UNK)))
                        sentences.append(words_line)
                        labels.append(int(label))
                        # seq_lens.append(seq_len)
                    return sentences, labels
            else:
                sentences = []
                with open(path, 'r', encoding='UTF-8') as f:
                    for line in tqdm(f):
                        lin = line.strip()
                        if not lin:
                            continue

                        words_line = []
                        token = tokenizer(lin)
                        # seq_len = len(token)
                        if pad_size:
                            if len(token) < pad_size:
                                token.extend([self.PAD] *
                                             (pad_size - len(token)))
                            else:
                                token = token[:pad_size]
                                seq_len = pad_size
                        for word in token:
                            words_line.append(
                                vocab.get(word, vocab.get(self.UNK)))
                        sentences.append(words_line)

                    return sentences

        train_text, train_labels = load_dataset(self.config.train_path,
                                                self.config.pad_size)
        dev_text, dev_labels = load_dataset(self.config.dev_path,
                                            self.config.pad_size)
        test_text = load_dataset(self.config.test_path,
                                 self.config.pad_size,
                                 mode='test')
        print(train_text[:10])
        print(train_labels[:10])
        print(dev_text[:10])
        print(dev_labels[:10])
        print(test_text[:10])

        return train_text, train_labels, dev_text, dev_labels, test_text, vocab_size


class DatasetGenerator:

    def __init__(self, text, labels):
        self.text = text
        self.labels = labels

    def __getitem__(self, index):
        return self.text[index], self.labels[index]

    def __len__(self):
        return len(self.text)
