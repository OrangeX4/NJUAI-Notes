import mindspore
import mindspore.nn as nn
import mindspore.ops as ops


class TextCNN(nn.Cell):
    """
        Architecture:
            Embedding -> Conv -> MaxPool -> Dropout -> FC
    """

    def __init__(self, config):
        super(TextCNN, self).__init__()

        self.embedding = nn.Embedding(vocab_size=config.vocab_size,
                                      embedding_size=config.embedding_size)
        # 特别注意如果用卷积，要指定pad_mode的不同模式 默认的pad_mode会通过pad使得卷积前后大小一致
        self.conv = nn.Conv2d(1,
                              config.core_channels, (4, config.embedding_size),
                              pad_mode='valid')

        self.dropout = nn.Dropout(config.dropout)
        self.fc = nn.Dense(config.core_channels, config.num_classes)

        self.maxpool1d = nn.MaxPool1d(kernel_size=29)

        self.squeeze_dims_1 = ops.Squeeze(
            axis=1)  #这样写是压缩axis=1上的维度，如果该维度不为1，报错
        self.squeeze_dims = ops.Squeeze()  #这样写是将tensor中所有维度为1的压缩掉
        # 注意看这里shape relu等使用方法，要先声明再用
        self.shape = ops.Shape()
        self.relu = nn.ReLU()
        self.expand_dims = ops.ExpandDims()
        self.concat = mindspore.ops.Concat(axis=1)

    # 卷积池化操作
    def conv_and_pool(self, x, conv, maxpool):
        x = self.squeeze_dims(self.relu(conv(x)))
        x = self.squeeze_dims(maxpool(x))
        return x

    #等于forward
    def construct(self, x):
        embedding_x = self.embedding(x)
        out = self.expand_dims(embedding_x, 1)
        out = self.conv_and_pool(out, self.conv, self.maxpool1d)
        out = self.fc(self.dropout(out))
        return out
